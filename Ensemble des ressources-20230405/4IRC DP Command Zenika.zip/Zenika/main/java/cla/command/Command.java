package cla.command;

@FunctionalInterface
public interface Command {
	void execute();
}
